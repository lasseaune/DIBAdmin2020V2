﻿namespace DIBAdminAPI.Helpers.Extentions
{
    public class List<T1, T2>
    {
    }
}