﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using System.Xml.Linq;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Microsoft.Extensions.Configuration;
using DIBAdminAPI.Data.Entities;
using DIBAdminAPI.Services;
using System.Linq;

namespace DIBAdminAPI.Data
{
    public class Repository : IRepository
    {
        private readonly ILogger<Repository> _logger;
        private readonly IConfiguration _configuration;
        private readonly string _connstring;
        


        public Repository(IConfiguration configuration, ILogger<Repository> logger)
        {
            _configuration = configuration;
            _connstring = "Server=rocky;Database=TM2020;Persist Security Info=True;User ID=dibapp;Password=lau610523;MultipleActiveResultSets=true;";
            _logger = logger;
        }



        private IDbConnection dbConnection
        {
            get
            {
                return new SqlConnection(_connstring);
            }
        }
        public async Task<XElement> ExecDocument(string QueryName, object p, int? timeOut = null)
        {
            IEnumerable<XElement> result;
            if (!timeOut.HasValue)
                timeOut = 60;



            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    try
                    {
                        result = await conn.QueryAsync<XElement>(QueryName, p, null, null, CommandType.StoredProcedure);
                        return result.FirstOrDefault();
                    }
                    catch(Exception e)
                    {

                    }
                    
                    
                }



                
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', p = '{@p}', Message = '{err}'", QueryName, p, e.Message);
            }
            return null;
        }
        public async Task<IEnumerable<TopicBase>> ExecTopics(string QueryName, object p, int? timeOut = null)
        {
            IEnumerable<TopicBase> result;
            if (!timeOut.HasValue)
                timeOut = 60;



            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    
                    result = await conn.QueryAsync<TopicBase>(QueryName, p, null, null, CommandType.StoredProcedure);
                }



                return result;
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', p = '{@p}', Message = '{err}'", QueryName, p, e.Message);
            }
            return null;
        }
        public async Task<TopicDetails> ExecTopicDetails(string QueryName, object p, int? timeOut = null)
        {
            TopicDetails result = new TopicDetails();
            if (!timeOut.HasValue)
                timeOut = 60;
            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    using (var multi = await conn.QueryMultipleAsync(QueryName, p, null, null, CommandType.StoredProcedure))
                    {
                        result.topics = multi.Read<Topic>();
                        result.topicNames = multi.Read<TopicNames>();
                        result.topicDatabases = multi.Read<TopicDatabase>();
                        result.topicResources = multi.Read<Resources>();
                    }
                }

                return result;
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', Message = '{err}'", QueryName, e.Message);
            }
            return null;
        }
        public async Task<TopicDetail> ExecTopicDetail(string QueryName, object p, int? timeOut = null)
        {
            TopicDetail result = new TopicDetail();
            if (!timeOut.HasValue)
                timeOut = 60;
            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    using (var multi = await conn.QueryMultipleAsync(QueryName, p,null, null, CommandType.StoredProcedure))
                    {
                        result = multi.Read<TopicDetail>().FirstOrDefault();
                        result.TopicNames = multi.Read<TopicName>().ToList();
                        result.Databases = multi.Read<int>().ToList();
                        result.Tags = multi.Read<Tag>().ToList();
                        result.description = multi.Read<string>().FirstOrDefault();
                        result.Dates = multi.Read<Dates>().ToList();
                        result.Related = multi.Read<TopicBase>().ToList();
                        result.Resources = multi.Read<Resource>().ToList();
                    }
                }

                return result;
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', Message = '{err}'", QueryName, e.Message);
            }
            return null;
        }
        public async Task<DIBObjects> ExecDIBObjects(string QueryName, object p, int? timeOut = null)
        {
            DIBObjects result = new DIBObjects();
            if (!timeOut.HasValue)
                timeOut = 60;

            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    //var r = await conn.QueryAsync<Home>(QueryName, null, null, null, CommandType.StoredProcedure);
                    //result = r.FirstOrDefault();
                    using (var multi = await conn.QueryMultipleAsync(QueryName, p))
                    {
                        result.Suppliers = multi.Read<Supplier>().ToList();
                        result.Topictypes = multi.Read<Topictype>().ToList();
                        result.Categories = multi.Read<Category>().ToList();
                        result.Databases = multi.Read<Database>().ToList();
                        result.Tagtypes = multi.Read<Tagtype>().ToList();
                        result.TopicNameTypes = multi.Read<TopicNameType>().ToList();
                        result.DateTypes = multi.Read<DateType>().ToList();
                        result.ResourceTypes = multi.Read<ResourceType>().ToList();
                        result.topics = multi.Read<Topic>();
                        result.topicNames = multi.Read<TopicNames>();
                        result.topicDatabases = multi.Read<TopicDatabase>();
                        result.topicResources = multi.Read<Resources>();
                        result.accountingTypes = multi.Read<AccountingType>();
                        result.accountingCodes = multi.Read<AccountingCode>();
                        result.accountingTaxes = multi.Read<AccountingTax>();
                    }
                }



                return result;
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', Message = '{err}'", QueryName, e.Message);
            }
            return null;
        }
        public async Task<Home> ExecHome(string QueryName, object p, int? timeOut = null)
        {
            Home result = new Home();
            if (!timeOut.HasValue)
                timeOut = 60;

            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    //var r = await conn.QueryAsync<Home>(QueryName, null, null, null, CommandType.StoredProcedure);
                    //result = r.FirstOrDefault();
                    using (var multi = await conn.QueryMultipleAsync(QueryName, p))
                    {
                        result.Suppliers = multi.Read<Supplier>().ToList();
                        result.Topictypes = multi.Read<Topictype>().ToList();
                        result.Categories = multi.Read<Category>().ToList();
                        result.Databases = multi.Read<Database>().ToList();
                        result.Tagtypes = multi.Read<Tagtype>().ToList();
                        result.TopicNameTypes = multi.Read<TopicNameType>().ToList();
                        result.DateTypes = multi.Read<DateType>().ToList();
                        result.ResourceTypes = multi.Read<ResourceType>().ToList();
                    }
                }



                return result;
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', Message = '{err}'", QueryName,  e.Message);
            }
            return null;
        }
        public async Task<IEnumerable<XElement>> ExecQuery(string QueryName, object p, int? timeOut = null)
        {
            IEnumerable<XElement> result;
            if (!timeOut.HasValue)
                timeOut = 60;
            try
            {
                using (IDbConnection conn = dbConnection)
                {
                    result = await conn.QueryAsync<XElement>(QueryName,p,null,null,CommandType.StoredProcedure);
                }
                return result;
            }
            catch (Exception e)
            {
                _logger.LogError("<Repository/ExecQuery> Query = '{queryName}', p = '{@p}', Message = '{err}'", QueryName, p, e.Message);
            }
            return null;
        }
    }
}