﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIBAdminAPI.Data.Entities
{
    public class Tagtype
    {
        public int tag_type_id { get; set; }
        public string name { get; set; }
    }
}
