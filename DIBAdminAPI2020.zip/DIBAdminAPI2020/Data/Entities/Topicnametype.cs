﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIBAdminAPI.Data.Entities
{
    public class TopicNameType
    {
        public int topic_name_type_id { get; set; }
        public string name { get; set; }
    }
}
