﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIBAdminAPI.Data.Entities
{
    public class Supplier
    {
        public int supplier_id { get; set; }
        public string name { get; set; }
        public string logoname { get; set; }
    }
}
