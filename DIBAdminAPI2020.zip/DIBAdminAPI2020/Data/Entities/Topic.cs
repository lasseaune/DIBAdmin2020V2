﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIBAdminAPI.Data.Entities
{
    public class TopicDetail
    {
        public Guid topic_id { get; set; }
        public string language { get; set; }
        public bool publish { get; set; }
        public int supplier_id { get; set; }
        public int topic_type_id { get; set; }
        public string short_description { get; set; }
        public string description { get; set; }
        public IEnumerable<int> Databases { get; set; }
        public IEnumerable<TopicName> TopicNames { get; set; }
        public IEnumerable<Tag> Tags { get; set; }
        public IEnumerable<Dates> Dates { get; set; }
        public IEnumerable<TopicBase> Related { get; set; }
        public IEnumerable<Resource> Resources { get; set; }

    }
    public class TopicBase
    {
        public Guid topic_id { get; set; }
        public string name { get; set; }
        public string language { get; set; }
        public bool publish { get; set; }
        public int supplier_id { get; set; }
        public int topic_type_id { get; set; }
        public string short_description { get; set; }

    }
    public class TopicDetails
    {
        public IEnumerable<Topic> topics { get; set; }
        public IEnumerable<TopicNames> topicNames { get; set; }
        public IEnumerable<TopicDatabase> topicDatabases { get; set; } 
        public IEnumerable<Resources> topicResources { get; set; }
    }
    public class Topic
    {
        public Guid topic_id { get; set; }
        public string language { get; set; }
        public bool publish { get; set; }
        public int supplier_id { get; set; }
        public int topic_type_id { get; set; }
        public string short_description { get; set; }
        public string description { get; set; }
    }
    public class TopicNames
    {
        public Guid topic_id { get; set; }
        public Guid topic_name_id { get; set; }
        public string name { get; set; }
        public bool isdefault { get; set; }
        public int topic_name_type_id { get; set; }
    }
    public class TopicDatabase
    {
        public Guid topic_id { get; set; }
        public int database_id { get; set; }
    }
}
