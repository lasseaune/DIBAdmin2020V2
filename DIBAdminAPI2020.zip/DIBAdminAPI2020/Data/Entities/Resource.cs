﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DIBAdminAPI.Data.Entities
{
    public class Resources
    {
        public Guid topic_id { get; set; }
        public Guid resource_id { get; set; }
        public int resource_type_id { get; set; }
        public DateTime updatedate { get; set; }
        public string username { get; set; }
        public string language { get; set; }
    }
    public class Resource
    {
        public Guid resource_id { get; set; }
        public int resource_type_id { get; set; }
        public DateTime updatedate { get; set; }
        public string username { get; set; }
        public string language { get; set; }
    }

    public class ResourceType
    {
        public int resource_type_id { get; set; }
        public string name { get; set; }
        public string data_type { get; set; }
        public int storage_id { get; set; }

}
}

